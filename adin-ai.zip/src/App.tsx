import React, { useState, useEffect, useRef } from "react";
import {
  Plus,
  Search,
  MessageSquare,
  Compass,
  Bookmark,
  Globe,
  FileText,
  Calculator,
  Code2,
  Settings,
  HelpCircle,
  Send,
  Sparkles,
  Trash2,
  Volume2,
  VolumeX,
  Star,
  Copy,
  Check,
  ExternalLink,
  FileUp,
  X,
  User,
  Activity
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import { AppMode, Message, ChatSession, SettingsState, Citation } from "./types";
import { PROMPT_PRESETS, AGENT_CARDS } from "./data";
import { AisMarkdown } from "./components/AisMarkdown";
import { playRawPcm, stopPcmAudio } from "./utils/audio";

export default function App() {
  // --- STATE MANAGEMENTS ---
  const [activeTab, setActiveTab] = useState<"chats" | "explore" | "bookmarks" | "settings">("chats");
  const [activeMode, setActiveMode] = useState<AppMode>("chat");
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [inputValue, setInputValue] = useState("");
  const [searchHistoryQuery, setSearchHistoryQuery] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Custom narrative parameters
  const [playingMessageId, setPlayingMessageId] = useState<string | null>(null);
  const [isAudioLoading, setIsAudioLoading] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);

  // Document Analyzer state
  const [uploadedDoc, setUploadedDoc] = useState<{ name: string; content: string } | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Premium platform configurations
  const [settings, setSettings] = useState<SettingsState>({
    voice: "Zephyr",
    temperature: 0.7,
    userName: "Premium Workspace User",
    premiumTheme: "indigo-violet"
  });

  // --- LOCALSTORAGE CACHE INTEGRATION ---
  useEffect(() => {
    try {
      const storedSessions = localStorage.getItem("adin_ai_sessions");
      if (storedSessions) {
        setSessions(JSON.parse(storedSessions));
      } else {
        // Create initial welcoming session
        const welcomeSession: ChatSession = {
          id: "welcome-thread",
          title: "Introduction Walkthrough",
          mode: "chat",
          createdAt: new Date().toISOString(),
          messages: [
            {
              id: "msg-welcome-1",
              role: "assistant",
              text: "Welcome to **Adin AI**, the ultimate premium multi-disciplinary reasoning playground. \n\nI have been specialized with key functional intelligence modules:\n- 🌐 **Web Grounded Search**: Active real-time Google search indices with automated cited reference mapping.\n- 📐 **Elite Math Solver**: Rigorous step-by-step analytical derivation oracle.\n- 💻 **Oracle Developer Companion**: Fully documented source structure algorithms.\n- 📄 **Executive Doc Analyzer**: Seamless plain text parse summarries.\n\nCustomize my settings parameter, select your theme, upload files, or ask me any query above. How can I augment your intelligence today?",
              timestamp: new Date().toISOString(),
              mode: "chat"
            }
          ]
        };
        setSessions([welcomeSession]);
        setActiveSessionId("welcome-thread");
      }

      const storedSettings = localStorage.getItem("adin_ai_settings");
      if (storedSettings) {
        setSettings(JSON.parse(storedSettings));
      }
    } catch (err) {
      console.error("Cache error:", err);
    }
  }, []);

  // Save updates to localStorage
  const saveSessionsToStorage = (updatedList: ChatSession[]) => {
    setSessions(updatedList);
    try {
      localStorage.setItem("adin_ai_sessions", JSON.stringify(updatedList));
    } catch (e) {
      console.error("Storage write error:", e);
    }
  };

  const saveSettingsToStorage = (updatedSettings: SettingsState) => {
    setSettings(updatedSettings);
    try {
      localStorage.setItem("adin_ai_settings", JSON.stringify(updatedSettings));
    } catch (e) {
      console.error("Storage write error:", e);
    }
  };

  // --- CORE UI HELPERS & MODE COLORS ---
  const activeSession = sessions.find(s => s.id === activeSessionId) || null;

  // Active theme gradient generator
  const getThemeGradient = (type: "bg" | "text" | "border" | "glow" | "navActive") => {
    const theme = settings.premiumTheme;
    if (theme === "emerald-teal") {
      switch (type) {
        case "bg": return "from-emerald-600 to-teal-500";
        case "text": return "from-emerald-400 to-teal-400 bg-clip-text text-transparent";
        case "border": return "border-emerald-500/20";
        case "glow": return "rgba(16,185,129,0.35)";
        case "navActive": return "from-emerald-600/20 to-teal-500/10 border-emerald-500/20";
      }
    }
    if (theme === "amber-orange") {
      switch (type) {
        case "bg": return "from-amber-500 to-orange-500";
        case "text": return "from-amber-400 to-orange-400 bg-clip-text text-transparent";
        case "border": return "border-amber-500/20";
        case "glow": return "rgba(245,158,11,0.35)";
        case "navActive": return "from-amber-500/20 to-orange-500/10 border-amber-500/20";
      }
    }
    if (theme === "crimson-ruby") {
      switch (type) {
        case "bg": return "from-rose-600 to-red-500";
        case "text": return "from-rose-400 to-red-400 bg-clip-text text-transparent";
        case "border": return "border-rose-500/20";
        case "glow": return "rgba(244,63,94,0.35)";
        case "navActive": return "from-rose-600/20 to-red-500/10 border-rose-500/20";
      }
    }
    // Default indigo-violet
    switch (type) {
      case "bg": return "from-violet-600 to-blue-500";
      case "text": return "from-violet-400 to-blue-400 bg-clip-text text-transparent";
      case "border": return "border-violet-500/20";
      case "glow": return "rgba(139,92,246,0.35)";
      case "navActive": return "from-violet-600/20 to-blue-500/10 border-violet-500/20";
    }
  };

  const getThemeBtnClass = () => {
    return `rounded-2xl bg-gradient-to-r ${getThemeGradient("bg")} flex items-center justify-center text-white font-medium hover:scale-[1.02] active:scale-95 transition-all duration-300`;
  };

  // --- ACTIONS ---

  // Initialize a new clear thread
  const handleNewChat = (forcedMode?: AppMode) => {
    const selectedMode = forcedMode || activeMode;
    const newSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: `Draft Workspace: ${getModeLabel(selectedMode)}`,
      mode: selectedMode,
      messages: [],
      createdAt: new Date().toISOString()
    };

    const updatedSessions = [newSession, ...sessions];
    saveSessionsToStorage(updatedSessions);
    setActiveSessionId(newSession.id);
    setActiveTab("chats");
    setUploadedDoc(null);
  };

  // Switch to specific thread
  const handleSelectSession = (id: string) => {
    setActiveSessionId(id);
    const session = sessions.find(s => s.id === id);
    if (session) {
      setActiveMode(session.mode);
    }
    setActiveTab("chats");
  };

  // Delete a thread
  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = sessions.filter(s => s.id !== id);
    saveSessionsToStorage(updated);
    if (activeSessionId === id) {
      if (updated.length > 0) {
        setActiveSessionId(updated[0].id);
        setActiveMode(updated[0].mode);
      } else {
        setActiveSessionId(null);
      }
    }
  };

  const handleClearAllSessions = () => {
    saveSessionsToStorage([]);
    setActiveSessionId(null);
    setUploadedDoc(null);
  };

  // Send message to back-end
  const handleSendMessage = async (customText?: string) => {
    const rawInput = (customText || inputValue).trim();
    if (!rawInput && !uploadedDoc) return;

    // Stop current speaking track prior to new inquiries
    handleStopSpeaking();

    // Prepare text representation
    let userPrompt = rawInput;
    if (uploadedDoc && !rawInput) {
      userPrompt = `Please summarize this uploaded document:\n---\nTitle: ${uploadedDoc.name}\n\n${uploadedDoc.content}`;
    } else if (uploadedDoc && rawInput) {
      userPrompt = `Context Document: ${uploadedDoc.name}\n---\n${uploadedDoc.content}\n---\nUser query: ${rawInput}`;
    }

    // Capture or build current chat session
    let targetSession = activeSession;
    let currentSessions = [...sessions];

    if (!targetSession) {
      const newSessionId = `session-${Date.now()}`;
      targetSession = {
        id: newSessionId,
        title: userPrompt.substring(0, 28) + (userPrompt.length > 28 ? "..." : ""),
        mode: activeMode,
        messages: [],
        createdAt: new Date().toISOString()
      };
      currentSessions = [targetSession, ...currentSessions];
    } else {
      // If it has empty history, rename it correctly
      if (targetSession.messages.length === 0) {
        targetSession.title = userPrompt.substring(0, 28) + (userPrompt.length > 28 ? "..." : "");
      }
    }

    const userMessage: Message = {
      id: `msg-${Date.now()}-user`,
      role: "user",
      text: userPrompt,
      timestamp: new Date().toISOString(),
      mode: activeMode
    };

    targetSession.messages = [...targetSession.messages, userMessage];
    saveSessionsToStorage(currentSessions);
    setActiveSessionId(targetSession.id);
    setInputValue("");
    setIsGenerating(true);

    try {
      // POST payload to the full-stack server endpoints
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: targetSession.messages,
          mode: activeMode,
          temperature: settings.temperature
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "A severe infrastructure server interruption occurred.");
      }

      const data = await response.json();

      const aiMessage: Message = {
        id: `msg-${Date.now()}-ai`,
        role: "assistant",
        text: data.text,
        timestamp: new Date().toISOString(),
        mode: activeMode,
        citations: data.citations || []
      };

      targetSession.messages = [...targetSession.messages, aiMessage];
      saveSessionsToStorage([...currentSessions]);

    } catch (err: any) {
      console.error(err);
      const systemErrorMessage: Message = {
        id: `msg-${Date.now()}-err`,
        role: "assistant",
        text: `⚠️ **Adin Engine Notification**\n\n${err.message || "An error occurred during communication."}`,
        timestamp: new Date().toISOString(),
        mode: activeMode
      };
      targetSession.messages = [...targetSession.messages, systemErrorMessage];
      saveSessionsToStorage([...currentSessions]);
    } finally {
      setIsGenerating(false);
      // Clean document once summarized
      setUploadedDoc(null);
    }
  };

  // Bookmarking/starring messages
  const handleToggleBookmark = (msg: Message, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!activeSession) return;

    const updatedSessions = sessions.map(session => {
      return {
        ...session,
        messages: session.messages.map(m => {
          if (m.id === msg.id) {
            // Toggle local file system simulated bookmarks
            return { ...m, isBookmarked: !m.isBookmarked };
          }
          return m;
        })
      };
    });

    saveSessionsToStorage(updatedSessions);
  };

  // Get list of all bookmarked messages across all sessions
  const getBookmarkedMessages = () => {
    const list: { sessionTitle: string; sessionId: string; message: Message }[] = [];
    sessions.forEach(session => {
      session.messages.forEach((msg: any) => {
        if (msg.isBookmarked) {
          list.push({
            sessionTitle: session.title,
            sessionId: session.id,
            message: msg
          });
        }
      });
    });
    return list;
  };

  // Copy helper
  const handleCopyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    // Visual feedback handled by state temporary labels if needed
  };

  // --- NARRATION AUDIO SPEECH FLOW ---
  const handleSpeakText = async (msg: Message, e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (playingMessageId === msg.id) {
      handleStopSpeaking();
      return;
    }

    handleStopSpeaking();
    setPlayingMessageId(msg.id);
    setIsAudioLoading(true);
    setAudioError(null);

    try {
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: msg.text,
          voice: settings.voice
        })
      });

      if (!res.ok) {
        throw new Error("Could not construct premium text synth audio stream. Verify Server status.");
      }

      const data = await res.json();
      
      // Play raw PCM data
      await playRawPcm(
        data.audio,
        24000,
        () => {
          // Finished callback
          setPlayingMessageId(null);
        },
        (err) => {
          setAudioError(err);
          setIsAudioLoading(false);
          setPlayingMessageId(null);
        }
      );

      setIsAudioLoading(false);

    } catch (err: any) {
      console.error(err);
      setAudioError(err.message || "Narrator failed to render voice block.");
      setIsAudioLoading(false);
      setPlayingMessageId(null);
    }
  };

  const handleStopSpeaking = () => {
    stopPcmAudio();
    setPlayingMessageId(null);
    setIsAudioLoading(false);
  };

  // File loading helpers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileLoad(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileLoad(e.target.files[0]);
    }
  };

  const handleFileLoad = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setUploadedDoc({
        name: file.name,
        content: content
      });
      // Force change mode to Document summaries context
      setActiveMode("document");
    };
    reader.readAsText(file);
  };

  // Pre-fill search/explore presets
  const handleUsePreset = (preset: typeof PROMPT_PRESETS[0]) => {
    setActiveMode(preset.mode);
    setInputValue(preset.prompt);
    setActiveTab("chats");
  };

  // Clean label of selected mode
  const getModeLabel = (m: AppMode) => {
    switch (m) {
      case "chat": return "General Chat";
      case "search": return "Grounded Search";
      case "math": return "Math Reasoning";
      case "code": return "Coding Companion";
      case "document": return "Document Analyst";
    }
  };

  // Search filter conversation list
  const filteredSessions = sessions.filter(s => {
    if (!searchHistoryQuery) return true;
    return s.title.toLowerCase().includes(searchHistoryQuery.toLowerCase()) || 
           s.messages.some(m => m.text.toLowerCase().includes(searchHistoryQuery.toLowerCase()));
  });

  return (
    <main className="flex h-screen bg-[#050505] text-white font-sans overflow-hidden select-none">
      
      {/* SIDEBAR NAVIGATION PANEL */}
      <aside className="w-[300px] bg-[#070707] border-r border-white/5 flex flex-col justify-between shrink-0 select-none">
        
        {/* LOGO SECTION */}
        <div className="p-5 flex flex-col flex-1 overflow-hidden">
          <div className="flex items-center gap-3 mb-6">
            <div className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${getThemeGradient("bg")} flex items-center justify-center shadow-[0_0_30px_rgba(139,92,246,0.25)]`}>
              <Sparkles size={19} className="text-white animate-pulse" />
            </div>
            <div>
              <h1 className="text-[21px] font-bold tracking-tight text-white leading-tight">Adin AI</h1>
              <p className="text-zinc-500 text-xs tracking-wide">Premium Synthetic Mind</p>
            </div>
          </div>

          {/* NEW CHAT INITIATION */}
          <button 
            type="button"
            onClick={() => handleNewChat()}
            className={`${getThemeBtnClass()} w-full h-[52px] gap-2 mb-6 cursor-pointer shadow-[0_4px_20px_rgba(0,0,0,0.3)]`}
          >
            <Plus size={18} />
            New Workspace
          </button>

          {/* SECTION TABS */}
          <div className="space-y-1 mb-6 shrink-0">
            <button
              onClick={() => setActiveTab("chats")}
              className={`w-full h-11 px-4 rounded-xl flex items-center justify-between text-[14px] transition-all duration-200 cursor-pointer ${
                activeTab === "chats" 
                  ? `bg-gradient-to-r ${getThemeGradient("navActive")} text-white font-medium` 
                  : "text-zinc-400 hover:text-white hover:bg-white/[0.02]"
              }`}
            >
              <div className="flex items-center gap-3">
                <MessageSquare size={17} className={activeTab === "chats" ? "text-violet-400" : ""} />
                <span>My Chats</span>
              </div>
              <span className="text-xs bg-white/5 text-zinc-500 px-2 py-0.5 rounded-md">{sessions.length}</span>
            </button>

            <button
              onClick={() => setActiveTab("explore")}
              className={`w-full h-11 px-4 rounded-xl flex items-center gap-3 text-[14px] transition-all duration-200 cursor-pointer ${
                activeTab === "explore" 
                  ? `bg-gradient-to-r ${getThemeGradient("navActive")} text-white font-medium` 
                  : "text-zinc-400 hover:text-white hover:bg-white/[0.02]"
              }`}
            >
              <Compass size={17} className={activeTab === "explore" ? "text-violet-400" : ""} />
              <span>Explore Library</span>
            </button>

            <button
              onClick={() => setActiveTab("bookmarks")}
              className={`w-full h-11 px-4 rounded-xl flex items-center justify-between text-[14px] transition-all duration-200 cursor-pointer ${
                activeTab === "bookmarks"
                  ? `bg-gradient-to-r ${getThemeGradient("navActive")} text-white font-medium` 
                  : "text-zinc-400 hover:text-white hover:bg-white/[0.02]"
              }`}
            >
              <div className="flex items-center gap-3">
                <Bookmark size={17} className={activeTab === "bookmarks" ? "text-violet-400" : ""} />
                <span>Starred Prompts</span>
              </div>
              <span className="text-xs bg-white/5 text-zinc-500 px-2 py-0.5 rounded-md">
                {getBookmarkedMessages().length}
              </span>
            </button>
          </div>

          {/* TAB DETAILED CONTENTS */}
          <div className="flex-1 flex flex-col min-h-0">
            
            {activeTab === "chats" && (
              <div className="flex-1 flex flex-col min-h-0">
                <div className="mb-3 px-1 relative">
                  <span className="absolute left-3.5 top-2.5 text-zinc-600">
                    <Search size={14} />
                  </span>
                  <input
                    type="text"
                    placeholder="Filter conversations..."
                    value={searchHistoryQuery}
                    onChange={(e) => setSearchHistoryQuery(e.target.value)}
                    className="w-full text-xs py-2 pl-9 pr-3 rounded-lg bg-white/[0.02] border border-white/5 outline-none text-zinc-300 placeholder:text-zinc-600 focus:border-white/10"
                  />
                  {searchHistoryQuery && (
                    <button onClick={() => setSearchHistoryQuery("")} className="absolute right-3 top-2 text-zinc-500 hover:text-white">
                      <X size={12} />
                    </button>
                  )}
                </div>

                <p className="text-zinc-600 text-[10px] tracking-[0.2em] font-medium uppercase px-1 mb-2">History threads</p>
                <div className="flex-1 overflow-y-auto space-y-1 pr-1 custom-scrollbar min-h-0">
                  {filteredSessions.length === 0 ? (
                    <div className="text-center py-8 text-zinc-600 text-xs italic">
                      No matching threads found.
                    </div>
                  ) : (
                    filteredSessions.map((session) => {
                      const isActive = session.id === activeSessionId;
                      return (
                        <div
                          key={session.id}
                          onClick={() => handleSelectSession(session.id)}
                          className={`group w-full px-3 py-2.5 rounded-xl flex items-center justify-between transition-all duration-200 cursor-pointer relative ${
                            isActive 
                              ? "bg-white/[0.03] border border-white/5" 
                              : "hover:bg-white/[0.01]"
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0 pr-4">
                            <span className="text-zinc-500 shrink-0">
                              {session.mode === "search" && <Globe size={14} className="text-cyan-400" />}
                              {session.mode === "math" && <Calculator size={14} className="text-amber-400" />}
                              {session.mode === "code" && <Code2 size={14} className="text-emerald-400" />}
                              {session.mode === "document" && <FileText size={14} className="text-rose-400" />}
                              {session.mode === "chat" && <MessageSquare size={14} className="text-violet-400" />}
                            </span>
                            <span className={`text-xs truncate transition-colors ${isActive ? "text-white font-medium" : "text-zinc-400 group-hover:text-zinc-200"}`}>
                              {session.title || "Empty Workspace"}
                            </span>
                          </div>
                          
                          <button
                            type="button"
                            onClick={(e) => handleDeleteSession(session.id, e)}
                            className="opacity-0 group-hover:opacity-100 p-1 hover:bg-white/10 rounded-lg text-zinc-500 hover:text-red-400 transition-all cursor-pointer shrink-0"
                            title="Delete thread"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      );
                    })
                  )}
                </div>

                {sessions.length > 0 && (
                  <button
                    onClick={handleClearAllSessions}
                    className="mt-2 w-full text-center py-2 border border-dashed border-white/5 text-[11px] text-zinc-500 hover:text-zinc-300 hover:border-white/10 rounded-lg transition-all cursor-pointer"
                  >
                    Clear All History
                  </button>
                )}
              </div>
            )}

            {activeTab === "explore" && (
              <div className="flex-1 flex flex-col min-h-0">
                <p className="text-zinc-600 text-[10px] tracking-[0.2em] font-medium uppercase px-1 mb-2">Engine Cards</p>
                <div className="flex-1 overflow-y-auto space-y-3 pr-1 min-h-0">
                  {PROMPT_PRESETS.map((preset) => (
                    <div
                      key={preset.id}
                      onClick={() => handleUsePreset(preset)}
                      className="p-3 bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 rounded-xl cursor-pointer hover:scale-[1.01] transition-all duration-200"
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs text-zinc-500 font-medium">{preset.subtitle}</span>
                        <span className="text-[9px] bg-white/5 text-zinc-400 px-1.5 py-0.5 rounded uppercase font-mono">
                          {preset.mode}
                        </span>
                      </div>
                      <h4 className="text-[13px] font-semibold text-zinc-200 group-hover:text-white mb-1">
                        {preset.title}
                      </h4>
                      <p className="text-[11px] text-zinc-500 line-clamp-2 leading-relaxed">
                        {preset.prompt}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "bookmarks" && (
              <div className="flex-1 flex flex-col min-h-0">
                <p className="text-zinc-600 text-[10px] tracking-[0.2em] font-medium uppercase px-1 mb-2">My Bookmarks</p>
                <div className="flex-1 overflow-y-auto space-y-3 pr-1 min-h-0">
                  {getBookmarkedMessages().length === 0 ? (
                    <div className="text-center py-10 text-zinc-600 text-xs italic">
                      Star helpful Gemini responses to see them consolidated here.
                    </div>
                  ) : (
                    getBookmarkedMessages().map(({ sessionTitle, sessionId, message }) => (
                      <div
                        key={message.id}
                        onClick={() => handleSelectSession(sessionId)}
                        className="p-3 bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 rounded-xl cursor-pointer transition-all duration-200"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] text-zinc-500 truncate max-w-[140px]">
                            In: {sessionTitle}
                          </span>
                          <span className="text-[9px] text-zinc-600 font-mono">
                            {new Date(message.timestamp).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-xs text-zinc-300 line-clamp-3 leading-relaxed">
                          {message.text}
                        </p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* PROFILE & GLOBAL MODULE SWITCHER */}
        <div className="p-4 border-t border-white/5 bg-[#0a0a0a]">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setActiveTab("settings")}
              className="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-zinc-400 hover:text-white transition-all cursor-pointer border border-white/5"
              title="Global settings configs"
            >
              <Settings size={18} />
            </button>
            <div className="flex-1 min-w-0">
              <h2 className="text-xs font-semibold text-white truncate">{settings.userName}</h2>
              <p className="text-[10px] text-zinc-600 uppercase font-mono tracking-wider">Premium Intelligence Active</p>
            </div>
            <div className="avatar w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xs font-bold text-white shadow-md">
              A
            </div>
          </div>
        </div>

      </aside>

      {/* CORE FRAME FOR RESPONSIVE RESPONSES */}
      <section className="flex-1 flex flex-col relative overflow-hidden min-w-0">
        
        {/* PREMIUM TOP HEADER CONTROLS */}
        <div className="h-[74px] border-b border-white/5 flex items-center justify-between px-8 bg-[#060606]/85 backdrop-blur z-20 shrink-0">
          <div className="flex items-center gap-4">
            <span className="font-semibold text-base text-zinc-400 capitalize">
              {activeSession ? (
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-ping"></span>
                  <span className="text-zinc-200 truncate max-w-xs">{activeSession.title}</span>
                </div>
              ) : (
                "New Creative Workspace"
              )}
            </span>
          </div>

          {/* ACTIVE MODE CONTROL CAPSULES */}
          <div className="flex items-center gap-1 bg-white/[0.02] border border-white/5 p-1 rounded-xl">
            {(["chat", "search", "math", "code", "document"] as AppMode[]).map((modeOption) => {
              const isActive = activeMode === modeOption;
              let icon = <MessageSquare size={14} />;
              let themeColor = "text-violet-400";
              
              if (modeOption === "search") { icon = <Globe size={14} />; themeColor = "text-cyan-400"; }
              else if (modeOption === "math") { icon = <Calculator size={14} />; themeColor = "text-amber-400"; }
              else if (modeOption === "code") { icon = <Code2 size={14} />; themeColor = "text-emerald-400"; }
              else if (modeOption === "document") { icon = <FileText size={14} />; themeColor = "text-rose-400"; }

              return (
                <button
                  key={modeOption}
                  onClick={() => {
                    setActiveMode(modeOption);
                    if (activeSession) {
                      // Dynamically upgrade running session mode parameter
                      const updated = sessions.map(s => s.id === activeSession.id ? { ...s, mode: modeOption } : s);
                      saveSessionsToStorage(updated);
                    }
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg transition-all duration-200 cursor-pointer text-zinc-400 hover:text-white ${
                    isActive ? "bg-white/5 text-white font-medium shadow-sm border border-white/5" : ""
                  }`}
                  title={`Switch to ${getModeLabel(modeOption)}`}
                >
                  <span className={isActive ? themeColor : "text-zinc-500"}>{icon}</span>
                  <span className="hidden xl:inline">{getModeLabel(modeOption)}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* SETTINGS BOARD OVERLAY / VIEW */}
        {activeTab === "settings" ? (
          <div className="flex-1 overflow-y-auto p-12 bg-[#050505] relative z-10 flex flex-col justify-between">
            <div className="max-w-2xl mx-auto w-full">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-zinc-300 border border-white/5">
                  <Settings size={22} className="text-violet-500" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold tracking-tight text-white mb-0.5">Platform Workspace Preferences</h3>
                  <p className="text-sm text-zinc-500">Fine-tune Adin's generative parameters, themes, and synthesis voice nodes.</p>
                </div>
              </div>

              <div className="space-y-8 bg-zinc-950/40 p-8 rounded-3xl border border-white/5">
                {/* USER PROFILE */}
                <div>
                  <label className="block text-xs uppercase tracking-wider text-zinc-500 font-mono mb-2">Your Name</label>
                  <input
                    type="text"
                    value={settings.userName}
                    onChange={(e) => saveSettingsToStorage({ ...settings, userName: e.target.value })}
                    className="w-full bg-white/[0.02] border border-white/5 rounded-xl px-4 py-3 outline-none focus:border-violet-500/40 text-sm text-white"
                  />
                </div>

                {/* VISUAL THEME SELECTION */}
                <div>
                  <label className="block text-xs uppercase tracking-wider text-zinc-500 font-mono mb-3">Premium Visual Core Theme</label>
                  <div className="grid grid-cols-4 gap-4">
                    {[
                      { id: "indigo-violet", label: "Midnight Indigo", color: "bg-indigo-600" },
                      { id: "emerald-teal", label: "Smaragd Marine", color: "bg-emerald-600" },
                      { id: "amber-orange", label: "Solar Amber", color: "bg-amber-500" },
                      { id: "crimson-ruby", label: "Rubellite Pulse", color: "bg-rose-600" },
                    ].map((themeOpt) => (
                      <button
                        key={themeOpt.id}
                        onClick={() => saveSettingsToStorage({ ...settings, premiumTheme: themeOpt.id as any })}
                        className={`p-3 rounded-2xl bg-[#09090c] border flex flex-col items-center justify-center gap-2 transition-all cursor-pointer ${
                          settings.premiumTheme === themeOpt.id 
                            ? "border-violet-500 bg-white/[0.02]" 
                            : "border-white/5 hover:border-white/10"
                        }`}
                      >
                        <span className={`w-5 h-5 rounded-full ${themeOpt.color}`}></span>
                        <span className="text-[11px] text-zinc-400">{themeOpt.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* TEMPERATURE CONFIGURATION */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-xs uppercase tracking-wider text-zinc-500 font-mono">Generative Creativity (Temperature)</label>
                    <span className="text-xs text-violet-400 font-semibold">{settings.temperature}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={settings.temperature}
                    onChange={(e) => saveSettingsToStorage({ ...settings, temperature: parseFloat(e.target.value) })}
                    className="w-full accent-violet-600 cursor-pointer h-1.5 bg-white/10 rounded-lg outline-none"
                  />
                  <div className="flex justify-between text-[10px] text-zinc-600 font-mono mt-1">
                    <span>Precision Logic (0.0)</span>
                    <span>Balanced Synthesis</span>
                    <span>Creative Brainstorm (1.0)</span>
                  </div>
                </div>

                {/* PREBUILT SPEAKING VOICE */}
                <div>
                  <label className="block text-xs uppercase tracking-wider text-zinc-500 font-mono mb-3">Narrator Prebuilt Voice Node</label>
                  <div className="grid grid-cols-5 gap-2">
                    {["Zephyr", "Kore", "Charon", "Fenrir", "Puck"].map((voiceOpt) => (
                      <button
                        key={voiceOpt}
                        onClick={() => saveSettingsToStorage({ ...settings, voice: voiceOpt as any })}
                        className={`py-2 px-3 rounded-xl border text-xs text-center transition-all cursor-pointer ${
                          settings.voice === voiceOpt 
                            ? "border-violet-500 bg-violet-500/10 text-white font-medium" 
                            : "border-white/5 bg-white/[0.01] hover:bg-white/[0.02] text-zinc-400"
                        }`}
                      >
                        {voiceOpt}
                      </button>
                    ))}
                  </div>
                  <p className="text-[10px] text-zinc-600 mt-2 italic font-mono">Uses Gemini Audio modalities synthesize to vocalize responses directly.</p>
                </div>
              </div>
            </div>
            
            <div className="text-center mt-12">
              <button 
                onClick={() => setActiveTab("chats")}
                className="px-6 py-2.5 rounded-xl bg-white/5 border border-white/5 text-xs font-mono tracking-wider hover:bg-white/10 transition-all cursor-pointer text-zinc-300 hover:text-white"
              >
                Return to Workspace Dialogue
              </button>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col relative overflow-hidden min-h-0 bg-[#050505]">
            
            {/* AMBIENT BACKGROUND GLOW AREA */}
            <div className="absolute w-[800px] h-[800px] bg-violet-600/5 blur-[160px] rounded-full top-[10%] left-[20%] pointer-events-none select-none" />

            {/* IF NO CONVERSATION ACTIVE OR CHAT IS EMPTY -> PRESENT PREMIUM LANDING PANEL */}
            {(!activeSession || activeSession.messages.length === 0) ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 overflow-y-auto relative z-10 min-h-0">
                
                {/* LARGE GORGEOUS HERO HEADER */}
                <motion.div 
                  initial={{ opacity: 0, y: 15 }} 
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6 }}
                  className="text-center max-w-3xl mb-12"
                >
                  <div className={`w-16 h-16 rounded-3xl bg-gradient-to-br ${getThemeGradient("bg")} flex items-center justify-center mx-auto mb-8 shadow-[0_12px_45px_${getThemeGradient("glow")}]`}>
                    <Sparkles size={28} className="text-white" />
                  </div>
                  
                  <h1 className="text-5xl md:text-6xl font-bold tracking-tight leading-tight text-white select-none">
                    Hello, I'm <span className={`bg-gradient-to-r ${getThemeGradient("text")}`}>{settings.userName.split(" ")[0]}</span>
                  </h1>
                  
                  <p className="mt-5 text-zinc-400 text-lg md:text-xl font-normal leading-relaxed max-w-2xl mx-auto">
                    A premium cognitive dashboard tailored for highly specialized assistance. Select a mode or type your inquiry below.
                  </p>
                </motion.div>

                {/* PREMIUM BENTO GRID SUGGESTIONS */}
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 w-full max-w-5xl px-4 select-none">
                  {AGENT_CARDS.map((agent, index) => {
                    let agentIcon = <MessageSquare size={18} />;
                    let iconColor = "text-violet-400 bg-violet-500/10";
                    if (agent.mode === "search") { agentIcon = <Globe size={18} />; iconColor = "text-cyan-400 bg-cyan-500/10"; }
                    if (agent.mode === "math") { agentIcon = <Calculator size={18} />; iconColor = "text-amber-400 bg-amber-500/10"; }
                    if (agent.mode === "code") { agentIcon = <Code2 size={18} />; iconColor = "text-emerald-400 bg-emerald-500/10"; }

                    return (
                      <motion.div
                        key={agent.id}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.08 + 0.2 }}
                        onClick={() => {
                          setActiveMode(agent.mode);
                          // Populate preview prompt preset
                          const matchingPreset = PROMPT_PRESETS.find(p => p.mode === agent.mode);
                          if (matchingPreset) {
                            setInputValue(matchingPreset.prompt);
                          }
                        }}
                        className="p-5 rounded-2xl bg-white/[0.01] hover:bg-white/[0.02] border border-white/5 hover:border-violet-500/20 shadow-sm transition-all duration-300 cursor-pointer group flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-center justify-between mb-4">
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${iconColor}`}>
                              {agentIcon}
                            </div>
                            <span className="text-[10px] text-zinc-600 font-mono tracking-wider uppercase">Active</span>
                          </div>
                          <h4 className="text-[15px] font-semibold text-zinc-200 group-hover:text-white mb-2">
                            {agent.name}
                          </h4>
                          <p className="text-xs text-zinc-500 leading-relaxed">
                            {agent.description}
                          </p>
                        </div>
                        
                        <div className="mt-4 pt-3 border-t border-white/5">
                          <span className="text-[10px] text-zinc-400 group-hover:text-violet-400 transition-colors flex items-center gap-1">
                            Load system presets &rarr;
                          </span>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

              </div>
            ) : (
              // ELSE: RENDER MULTI-BUBBLE CONVERSATION TIMELINE
              <div className="flex-1 overflow-y-auto p-8 space-y-8 select-text relative z-10 custom-scrollbar pr-6">
                
                {activeSession.messages.map((msg, i) => {
                  const isUser = msg.role === "user";
                  const isPlaying = playingMessageId === msg.id;
                  
                  return (
                    <div 
                      key={msg.id} 
                      className={`flex ${isUser ? "justify-end" : "justify-start"} max-w-4xl ${isUser ? "ml-auto" : "mr-auto"}`}
                    >
                      <div className={`flex gap-4 items-start w-full ${isUser ? "flex-row-reverse" : "flex-row"}`}>
                        
                        {/* AVATAR GEMS */}
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 font-bold text-xs select-none border border-white/5`}>
                          {isUser ? (
                            <span className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white w-full h-full flex items-center justify-center rounded-xl">U</span>
                          ) : (
                            <span className={`bg-gradient-to-br ${getThemeGradient("bg")} text-white w-full h-full flex items-center justify-center rounded-xl`}>G</span>
                          )}
                        </div>

                        {/* MESSAGE CONTAINER SHELL */}
                        <div className="flex-1 min-w-0">
                          
                          {/* SENDER INFO AND MODE TAGS */}
                          <div className={`flex items-center gap-2 mb-2 select-none ${isUser ? "justify-end" : "justify-start"}`}>
                            <span className="text-xs font-semibold text-zinc-300">
                              {isUser ? settings.userName : "Adin Assistant"}
                            </span>
                            <span className="text-[10px] text-zinc-600 font-mono">
                              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                            {!isUser && msg.mode && (
                              <span className="text-[9px] bg-white/5 border border-white/5 text-zinc-400 px-1.5 py-0.5 rounded font-mono uppercase tracking-wider">
                                {msg.mode} mode
                              </span>
                            )}
                          </div>

                          {/* MESSAGE BUBBLE */}
                          <div className={`p-6 rounded-2xl relative ${
                            isUser 
                              ? "bg-white/[0.02] border border-white/5 text-zinc-100 rounded-tr-none" 
                              : "bg-[#0a0a0d]/90 border border-white/5 text-zinc-200 rounded-tl-none shadow-[0_4px_30px_rgba(0,0,0,0.5)]"
                          }`}>
                            
                            {/* MARKDOWN RENDERER */}
                            <AisMarkdown content={msg.text} />

                            {/* SOURCE CITATIONS (ONLY INDEXED FOR SEARCH GROUNDED ANSWERS) */}
                            {!isUser && msg.citations && msg.citations.length > 0 && (
                              <div className="mt-5 pt-4 border-t border-white/5 select-none">
                                <p className="text-[11px] font-mono uppercase tracking-wider text-zinc-500 mb-2 flex items-center gap-1.5">
                                  <Globe size={11} className="text-cyan-400" /> Grounded Search Citations ({msg.citations.length})
                                </p>
                                <div className="flex flex-wrap gap-2">
                                  {msg.citations.map((cite: Citation, idx: number) => (
                                    <a
                                      key={idx}
                                      href={cite.url}
                                      target="_blank"
                                      referrerPolicy="no-referrer"
                                      className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-lg bg-white/5 border border-white/5 hover:bg-white/10 text-cyan-400 hover:text-cyan-300 transition-all font-mono"
                                    >
                                      <span>[{idx + 1}]</span>
                                      <span className="max-w-[120px] truncate">{cite.title}</span>
                                      <ExternalLink size={10} />
                                    </a>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* ACTIVE SPEAKING EQUALIZER VISUALIZER */}
                            {!isUser && isPlaying && (
                              <div className="mt-4 flex items-center gap-2 bg-violet-600/5 border border-violet-500/10 px-3 py-2 rounded-xl select-none">
                                <Activity size={14} className="text-violet-400 animate-pulse" />
                                <span className="text-xs font-mono text-violet-400">Oral synthesis active...</span>
                                <div className="flex items-center gap-0.5 h-3 ml-2">
                                  <span className="w-[2px] h-3 bg-violet-400 rounded-full animate-[bounce_1s_infinite_100ms]" />
                                  <span className="w-[2px] h-2 bg-violet-400 rounded-full animate-[bounce_1s_infinite_200ms]" />
                                  <span className="w-[2px] h-3.5 bg-violet-400 rounded-full animate-[bounce_1s_infinite_300ms]" />
                                  <span className="w-[2px] h-1.5 bg-violet-400 rounded-full animate-[bounce_1s_infinite_400ms]" />
                                </div>
                              </div>
                            )}

                            {/* IN-BOX REACTION FOOTER */}
                            {!isUser && (
                              <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between select-none">
                                
                                <div className="flex items-center gap-1">
                                  
                                  {/* Listen narrative audio button */}
                                  <button
                                    onClick={(e) => handleSpeakText(msg, e)}
                                    disabled={isAudioLoading && playingMessageId === msg.id}
                                    className={`p-2 rounded-lg hover:bg-white/5 transition-all flex items-center gap-1 text-zinc-400 hover:text-white cursor-pointer ${
                                      isPlaying ? "text-violet-400 bg-violet-500/10 hover:bg-violet-500/15" : ""
                                    }`}
                                    title={isPlaying ? "Stop Synthesis" : "Generate Custom AI Speech Speech"}
                                  >
                                    {isPlaying ? (
                                      <>
                                        <VolumeX size={14} className="text-violet-400" />
                                        <span className="text-xs font-mono text-violet-400">Stop</span>
                                      </>
                                    ) : (
                                      <>
                                        <Volume2 size={14} />
                                        <span className="text-xs font-mono">Narrate</span>
                                      </>
                                    )}
                                  </button>

                                  {/* Bookmark item button */}
                                  <button
                                    onClick={(e) => handleToggleBookmark(msg, e)}
                                    className={`p-2 rounded-lg hover:bg-white/5 transition-all text-zinc-400 hover:text-white cursor-pointer ${(msg as any).isBookmarked ? "text-amber-400 hover:text-amber-300" : ""}`}
                                    title={(msg as any).isBookmarked ? "Unstar response" : "Star and pin response"}
                                  >
                                    <Star size={14} fill={(msg as any).isBookmarked ? "currentColor" : "none"} />
                                  </button>
                                </div>

                                <button
                                  onClick={() => handleCopyToClipboard(msg.text, msg.id)}
                                  className="p-2 rounded-lg hover:bg-white/5 text-zinc-500 hover:text-white transition-all text-xs flex items-center gap-1 cursor-pointer"
                                  title="Copy prose"
                                >
                                  <Copy size={13} />
                                  <span className="font-mono text-[10px]">Copy</span>
                                </button>
                              </div>
                            )}

                          </div>
                          
                        </div>

                      </div>
                    </div>
                  );
                })}

                {/* VISUAL GENERATING / REASONING DOTS INDICATORS */}
                {isGenerating && (
                  <div className="flex justify-start max-w-4xl mr-auto pt-4">
                    <div className="flex gap-4 items-start w-full">
                      <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-600 to-blue-500 flex items-center justify-center shrink-0 font-bold text-xs select-none shadow">
                        A
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-zinc-300 mb-1 pointer-events-none select-none">
                          Adin Thinking
                        </div>
                        <div className="bg-[#0a0a0d]/90 border border-white/5 rounded-2xl rounded-tl-none p-5 flex items-center gap-3">
                          <div className="relative w-4 h-4 flex items-center justify-center">
                            <span className="absolute w-2.5 h-2.5 bg-violet-400 rounded-full animate-ping"></span>
                            <span className="absolute w-2.5 h-2.5 bg-violet-500 rounded-full"></span>
                          </div>
                          <span className="text-xs text-zinc-500 font-mono tracking-wide animate-pulse">Computing complex synthesis parameters...</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

              </div>
            )}

            {/* FLOATING AND DOCUMENT SUMMARY METRIC FLOATING CHANNELS */}
            {uploadedDoc && (
              <div className="mx-8 mt-2 p-3.5 bg-rose-950/20 border border-rose-500/20 rounded-2xl relative z-10 flex items-center justify-between select-none">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400">
                    <FileText size={16} />
                  </div>
                  <div>
                    <span className="text-xs font-mono text-zinc-400 block">Loaded Context File</span>
                    <span className="text-[13px] font-semibold text-rose-300 truncate max-w-[340px] block">{uploadedDoc.name}</span>
                  </div>
                </div>
                <button 
                  onClick={() => setUploadedDoc(null)} 
                  className="p-1.5 hover:bg-white/10 rounded-lg text-zinc-400 hover:text-white cursor-pointer"
                >
                  <X size={14} />
                </button>
              </div>
            )}

            {/* INPUT & FILE DRAG DROP BOX AT PAGE BOTTOM */}
            <div className="p-8 bg-[#050505] relative z-20 select-none">
              
              <div 
                className={`relative w-full max-w-5xl mx-auto rounded-3xl border ${
                  dragActive ? "border-violet-500 bg-violet-500/5 scale-[1.005]" : "border-white/5 bg-[#0a0a0c]/90"
                } shadow-[0_4px_45px_rgba(0,0,0,0.65)] transition-all duration-300`}
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
              >
                {/* File input handler */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".txt,.md,.js,.ts,.json"
                  className="hidden"
                  onChange={handleFileChange}
                />

                <div className="flex items-center gap-4 px-6 h-[78px]">
                  
                  {/* Quick toggle file upload button */}
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-11 h-11 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-zinc-400 hover:text-white transition-all cursor-pointer border border-white/5"
                    title="Upload plain text or source code files as context"
                  >
                    <FileUp size={18} />
                  </button>

                  {/* Input form element */}
                  <form
                    onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }}
                    className="flex-1 flex items-center gap-4"
                  >
                    <input
                      placeholder={
                        activeMode === "document" 
                          ? "Ask Adin questions about the loaded document context..." 
                          : `Type message to Adin (${getModeLabel(activeMode)} Mode)...`
                      }
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      disabled={isGenerating}
                      className="flex-1 bg-transparent border-none outline-none text-[15.5px] text-white placeholder:text-zinc-600"
                    />

                    {/* Submit message button with active state thematic gradients */}
                    <button
                      type="submit"
                      disabled={isGenerating || (!inputValue.trim() && !uploadedDoc)}
                      className={`w-12 h-12 rounded-xl bg-gradient-to-br ${getThemeGradient("bg")} flex items-center justify-center shadow-lg transition-transform hover:scale-105 active:scale-95 disabled:opacity-40 disabled:hover:scale-100 disabled:cursor-not-allowed`}
                    >
                      <Send size={18} className="text-white" />
                    </button>
                  </form>

                </div>

                {/* Subtitle helper showing dragging instructions */}
                <div className="px-6 pb-2 text-[9.5px] text-zinc-600 font-mono flex items-center justify-between border-t border-white/[0.02] pt-1.5">
                  <span className="hidden xl:inline">Tip: Drag & drop plain text code or text documents here to analyze details</span>
                  <span className="ml-auto">Ctrl + Enter to send</span>
                </div>

              </div>

            </div>

          </div>
        )}

      </section>
    </main>
  );
}
